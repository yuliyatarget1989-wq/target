# target-advance-ready

Готовый проект для Vercel.

**Инструкция по деплою (быстро):**

1. На GitHub: зайдите в репозиторий → Add file → Upload files → загрузите все файлы из архива (или загрузите папку). Commit changes.
2. В Vercel: New Project → Import from GitHub → выберите этот репозиторий → нажмите Deploy.

Файлы:
- pages/index.js — главная
- public/docs/contract-sample.pdf — пример договора
- public/images/logo.svg — логотип
- public/results/* — изображения кейсов и скриншоты
